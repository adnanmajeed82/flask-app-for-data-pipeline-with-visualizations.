from flask import Flask, render_template, request, redirect, url_for, flash, send_file
import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns
from io import BytesIO
import base64

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['UPLOAD_FOLDER'] = 'data'

# Ensure upload folder exists
if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    
    if file and file.filename.endswith('.xlsx'):
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        flash('File successfully uploaded')
        return redirect(url_for('process_file', filename=file.filename))
    else:
        flash('Only Excel files are allowed')
        return redirect(request.url)

@app.route('/process/<filename>')
def process_file(filename):
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    df = pd.read_excel(file_path)
    
    # Handle missing values and convert date columns to string for visualization compatibility
    df = df.fillna(0)  # Replace NaN values with 0
    for col in df.select_dtypes(include=['datetime', 'datetime64']).columns:
        df[col] = df[col].astype(str)  # Convert datetime columns to string for display
    
    # Generate Data Summary
    data_summary = df.describe(include='all').to_html(classes="table table-striped")

    # Save processed data
    processed_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'processed_' + filename)
    df.to_excel(processed_file_path, index=False)

    # Generate Plots
    plots = []
    numeric_columns = df.select_dtypes(include=['number']).columns  # Select only numeric columns

    if len(numeric_columns) >= 2:
        # Histogram of the first numeric column
        img = BytesIO()
        plt.figure()
        df[numeric_columns[0]].hist(bins=20, color='skyblue', edgecolor='black')
        plt.title(f'Histogram of {numeric_columns[0]}')
        plt.xlabel(numeric_columns[0])
        plt.ylabel('Frequency')
        plt.tight_layout()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plots.append(f'data:image/png;base64,{plot_url}')

        # Scatter plot between the first two numeric columns
        img = BytesIO()
        plt.figure()
        plt.scatter(df[numeric_columns[0]], df[numeric_columns[1]], color='coral')
        plt.title(f'Scatter Plot of {numeric_columns[0]} vs {numeric_columns[1]}')
        plt.xlabel(numeric_columns[0])
        plt.ylabel(numeric_columns[1])
        plt.tight_layout()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plots.append(f'data:image/png;base64,{plot_url}')

        # Box plot of the first numeric column
        img = BytesIO()
        plt.figure()
        sns.boxplot(y=df[numeric_columns[0]], color='lightgreen')
        plt.title(f'Box Plot of {numeric_columns[0]}')
        plt.ylabel(numeric_columns[0])
        plt.tight_layout()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plots.append(f'data:image/png;base64,{plot_url}')

        # Line plot of the first numeric column
        img = BytesIO()
        plt.figure()
        plt.plot(df[numeric_columns[0]], color='blue')
        plt.title(f'Line Plot of {numeric_columns[0]}')
        plt.xlabel('Index')
        plt.ylabel(numeric_columns[0])
        plt.tight_layout()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plots.append(f'data:image/png;base64,{plot_url}')

        # Correlation heatmap of all numeric columns
        img = BytesIO()
        plt.figure(figsize=(8, 6))
        sns.heatmap(df[numeric_columns].corr(), annot=True, cmap='coolwarm', fmt=".2f")
        plt.title('Correlation Heatmap')
        plt.tight_layout()
        plt.savefig(img, format='png')
        img.seek(0)
        plot_url = base64.b64encode(img.getvalue()).decode()
        plots.append(f'data:image/png;base64,{plot_url}')

    return render_template('process.html', summary=data_summary, filename=filename, plots=plots)

@app.route('/download/<filename>')
def download_file(filename):
    processed_file_path = os.path.join(app.config['UPLOAD_FOLDER'], 'processed_' + filename)
    return send_file(processed_file_path, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
